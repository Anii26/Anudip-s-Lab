export const CATEGORIES_URL = 'categories.php';
export const MEAL_CATEGORIES_URL = "filter.php?c=";
export const MEAL_SINGLE_URL  = "lookup.php?i=";
export const SEARCH_URL = "search.php?s=";