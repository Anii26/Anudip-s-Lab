import React from 'react'

const ErrorPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default ErrorPage
